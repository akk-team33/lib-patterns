package de.team33.cmd.files.job;

import de.team33.cmd.files.common.Output;
import de.team33.cmd.files.common.RequestException;
import de.team33.patterns.io.phobos.FileEntry;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.stream.Stream;

class DirCopying implements Runnable {

    static final String EXCERPT = "Copy the subdirectory structure from one directory to another.";

    private final Output out;
    private final Path source;
    private final Path target;

    private DirCopying(final Output out, final Path source, final Path target) {
        this.out = out;
        this.source = source;
        this.target = target;
    }

    static DirCopying job(final Output out, final List<String> args) throws RequestException {
        assert 1 < args.size();
        assert Command.DCOPY.name().equalsIgnoreCase(args.get(1));
        // - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -
        if (4 == args.size()) {
            final Path source = Path.of(args.get(2));
            final Path target = Path.of(args.get(3));
            return new DirCopying(out, source, target);
        }
        throw RequestException.format(DirCopying.class, "DirCopying.txt", Util.cmdLine(args), Util.cmdName(args));
    }

    @Override
    public void run() {
        copy(FileEntry.of(source).resolved().entries());
    }

    private void copy(final Stream<FileEntry> entries) {
        entries.forEach(this::copy);
    }

    private void copy(final FileEntry entry) {
        if (entry.isDirectory()) {
            copy(entry.entries());
            final Path relative = source.relativize(entry.path());
            out.printf("%s ...", relative);
            try {
                Files.createDirectories(target.resolve(relative));
                out.printf(" created%n", relative);
            } catch (final IOException e) {
                out.printf(" failed:%n" +
                           "    Message   : %s%n" +
                           "    Exception : %s%n", e.getMessage(), e.getClass().getCanonicalName());
            }
        }
    }
}
