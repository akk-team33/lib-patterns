package de.team33.patterns.test.testing.io;

import de.team33.patterns.testing.io.ZipIO;
import org.junit.jupiter.api.Test;

import java.nio.file.Path;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

class ZipIOTest {

    private static final Path TARGET_PATH = Path.of("target", "testing", UUID.randomUUID().toString())
                                                .toAbsolutePath()
                                                .normalize();

    @Test
    final void unzip() {
        ZipIO.unzip(ZipIOTest.class, "ZipIOTest.zip", TARGET_PATH);
    }
}
